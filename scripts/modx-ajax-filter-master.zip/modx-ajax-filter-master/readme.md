<h1>Ajax фильтр на MODx Revolution</h1>

<p>Статья на русском по использованию: http://webdesign-master.ru/blog/modx/2016-05-03-modx-ajax-filter.html</p>
